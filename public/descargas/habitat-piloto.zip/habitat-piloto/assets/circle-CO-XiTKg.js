import{c}from"./index-Bp9uYius.js";const r=c("Circle",[["circle",{cx:"12",cy:"12",r:"10",key:"1mglay"}]]);export{r as C};
