const u=new Set(["https:"]);function l(r){const t=r.trim();if(!t)return null;try{const n=new URL(t);return u.has(n.protocol)?n.toString():null}catch{return null}}export{l as u};
